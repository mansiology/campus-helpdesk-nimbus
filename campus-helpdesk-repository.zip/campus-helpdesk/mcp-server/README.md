# Campus Helpdesk MCP Server

## Requirements
- Python 3.11+
- MCP Python SDK 1.x (`mcp>=1.28,<2`)

## Install
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Run over stdio
```bash
python server.py
```
The server waits for an MCP client; stdio is the protocol transport.

## Inspect
```bash
mcp dev server.py
```
Use MCP Inspector to list tools, call both tools, and read `hostel://rules`.

## Tools
- `get_timetable(batch, day)` — fictional mock timetable
- `get_fee_status(student_id)` — fictional mock fee status

## Resource
- `hostel://rules` — fictional hostel rules document

No real student or financial data is used.
