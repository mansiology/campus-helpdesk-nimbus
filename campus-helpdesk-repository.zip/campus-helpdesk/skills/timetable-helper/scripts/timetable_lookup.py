import csv
import sys
from pathlib import Path

CSV_FILE = Path(__file__).resolve().parents[1] / "timetable.csv"
VALID_DAYS = {"monday", "tuesday", "wednesday", "thursday",
              "friday", "saturday", "sunday"}

def lookup(batch: str, day: str):
    if not batch.strip():
        raise ValueError("Batch cannot be empty.")
    if day.strip().casefold() not in VALID_DAYS:
        raise ValueError("Invalid weekday.")
    if not CSV_FILE.exists():
        raise FileNotFoundError("Timetable CSV not found.")
    with CSV_FILE.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        required = {"batch", "day", "start_time", "end_time",
                    "subject", "room", "instructor"}
        if not required.issubset(reader.fieldnames or []):
            raise ValueError("CSV is missing required columns.")
        rows = [r for r in reader
                if r["batch"].strip().casefold() == batch.strip().casefold()
                and r["day"].strip().casefold() == day.strip().casefold()]
    return sorted(rows, key=lambda r: r["start_time"])

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python timetable_lookup.py BATCH DAY")
        sys.exit(2)
    try:
        rows = lookup(sys.argv[1], sys.argv[2])
        if not rows:
            print("No timetable entries found.")
        for r in rows:
            print(f'{r["start_time"]}-{r["end_time"]} | {r["subject"]} | {r["room"]} | {r["instructor"]}')
    except (ValueError, FileNotFoundError) as e:
        print(f"Error: {e}")
        sys.exit(1)
