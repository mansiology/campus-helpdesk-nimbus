---
description: Retrieve timetable information for a batch and day
---

Use the timetable-helper Skill and the supplied CSV as the authoritative source.
Ask for missing batch or day information. Return matching entries in chronological
order. Never invent classes, times, rooms or instructors.
